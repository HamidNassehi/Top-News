Team Members - 
Hamid Nassehi, Jainam Patel, Joonkyu Sok
App Description - 
In this application, the user can retrieve the top news in one click. Then they can do a survey where how good the news was. 
API links -
https://newsapi.org/docs/endpoints/top-headlines
Youtube Demo Video - 
